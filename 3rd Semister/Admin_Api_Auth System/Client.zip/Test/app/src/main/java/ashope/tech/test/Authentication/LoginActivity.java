package ashope.tech.test.Authentication;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.os.Build.VERSION.SDK_INT;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import ashope.tech.test.R;

public class LoginActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (checkPermission()){
            Start_Login(this);
        } else {
            androidx.appcompat.app.AlertDialog.Builder AlertBox = new androidx.appcompat.app.AlertDialog.Builder(this);
            AlertBox.setTitle("Requesting Permissions")
                    .setMessage("Require file storage permission for the application to work")
                    .setCancelable(false)
                    .setPositiveButton("Allow", (dialog, which) -> {
                        requestPermission();
                        finish();
                    })
                    .setNegativeButton("No", (dialog, which) -> {
                        Start_Login(this);
                    })
                    .create()
                    .show();
        }
    }

    private boolean checkPermission() {
        if (SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        } else {
            int result = ContextCompat.checkSelfPermission(this, READ_EXTERNAL_STORAGE);
            int result1 = ContextCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE);
            return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void requestPermission() {
        if (SDK_INT >= Build.VERSION_CODES.R) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.addCategory("android.intent.category.DEFAULT");
                intent.setData(Uri.parse(String.format("package:%s", getPackageName())));
                startActivityForResult(intent, 2296);
                finish();
            } catch (Exception e) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivityForResult(intent, 2296);
                finish();
            }
        } else {
            ActivityCompat.requestPermissions(this, new String[]{WRITE_EXTERNAL_STORAGE}, 1001);
            finish();
        }
    }

    public void Start_Login(final Context context) {
        final SharedPreferences sharedPreferences = context.getSharedPreferences("SavePref", 0);
        String Token = sharedPreferences.getString("Token", null);

        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.setOrientation(LinearLayout.VERTICAL);

        GradientDrawable gradientdrawable = new GradientDrawable();
        gradientdrawable.setCornerRadius(20); //Set corner
        gradientdrawable.setColor(Color.parseColor("#1C2A35")); //Set background color
        gradientdrawable.setStroke(2, Color.parseColor("#32cb00")); //Set
        linearLayout.setBackground(gradientdrawable);

        //Create username edittext field
        TextView txt = new TextView(context);
        txt.setGravity(Gravity.CENTER);
        txt.setText("Login");
        txt.setTextColor(Color.WHITE);
        txt.setBackgroundColor(Color.TRANSPARENT);
        txt.setTextSize(20);

        EditText editTextUser = new EditText(context);
        if (Token != null && !Token.isEmpty()) {
            editTextUser.setText(Token);
        }
        editTextUser.setTextColor(Color.WHITE);
        editTextUser.setHintTextColor(Color.WHITE);
        editTextUser.setHint("Key");

        //Create checkbox
        CheckBox checkBox = new CheckBox(context);
        checkBox.setChecked(true);
        checkBox.setTextColor(Color.WHITE);
        checkBox.setText("Remember me");

        //Create button
        Button button = new Button(context);
        button.setText("Login");

        linearLayout.addView(txt);
        linearLayout.addView(editTextUser);
        linearLayout.addView(checkBox);
        linearLayout.addView(button);

        //Create alertdialog
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setCancelable(true);
        builder.setView(linearLayout);
        AlertDialog show = builder.show();

        final EditText editText3 = editTextUser;
        final CheckBox checkBox2 = checkBox;
        final AlertDialog alertDialog = show;

        button.setOnClickListener(view -> {
            String user = editText3.getText().toString().trim();

            boolean isChecked = checkBox2.isChecked();
            SharedPreferences.Editor edit = sharedPreferences.edit();
            if (!user.isEmpty()) {
                if (isChecked) {
                    edit.putString("Token", user);
                    edit.apply();
                } else {
                    edit.clear();
                    edit.apply();
                }
                new Auth(LoginActivity.this).execute(user);
                alertDialog.dismiss();
            }
        });
    }
}

