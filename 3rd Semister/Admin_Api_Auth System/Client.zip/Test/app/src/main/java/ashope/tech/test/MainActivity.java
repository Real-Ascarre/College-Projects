package ashope.tech.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import ashope.tech.test.Authentication.LoginActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        linearLayout.setOrientation(LinearLayout.VERTICAL);

        GradientDrawable gradientdrawable = new GradientDrawable();
        gradientdrawable.setCornerRadius(20);
        gradientdrawable.setColor(Color.parseColor("#1C2A35"));
        gradientdrawable.setStroke(2, Color.parseColor("#32cb00"));
        linearLayout.setBackground(gradientdrawable);

        TextView txt = new TextView(this);
        txt.setGravity(Gravity.CENTER);
        txt.setText("Welcome");
        txt.setTextColor(Color.WHITE);
        txt.setBackgroundColor(Color.TRANSPARENT);
        txt.setTextSize(20);

        Button button = new Button(this);
        button.setText("Logout");

        linearLayout.addView(txt);
        linearLayout.addView(button);

        button.setOnClickListener(view -> {
            startActivity(new Intent(this, LoginActivity.class));
            Toast.makeText(this, "Logged out Successfully", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}