Steps to setup the source
1. Go to your Website File Manager and Upload only Extractor.php and Source.zip file
2. GO to your website link and redirect to Extractor.php (https://__YOUR_SITE_LINK__/Extractor.php)
3. Click on Unarchive and on success close tab and come back to your file manager
4. Delete the Extractor.php and Source.zip file
5. Open your SQL database
6. upload the Sql.sql file or copy contents to for manual query
7. after success query come back to your file manager and update the database details inside database.php file
8. All done now you can access the api from "public/index.php" and admin from "admin/index.php" 

Example for Api call - (https://__YOUR_SITE_LINK__/public/index.php)

Example for Admin Panel - (https://__YOUR_SITE_LINK__/admin/index.php)

Admin Login Details - UserName & Password both are "admin"